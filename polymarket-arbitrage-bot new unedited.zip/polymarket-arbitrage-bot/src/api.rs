use crate::models::*;
use anyhow::Result;
use reqwest::Client;
use serde_json::Value;
use std::str::FromStr;
use polymarket_client_sdk::clob::{Client as ClobClient, Config as ClobConfig};
use polymarket_client_sdk::clob::types::{Side, SignatureType};
use polymarket_client_sdk::POLYGON;
use alloy::signers::local::LocalSigner;
use alloy::signers::Signer as _;
use alloy::primitives::{U256, Address};
use uuid::Uuid;

pub struct PolymarketApi {
    client: Client,
    gamma_url: String,
    clob_url: String,
    api_key: Option<String>,
    api_secret: Option<String>,
    api_passphrase: Option<String>,
    private_key: Option<String>,
    proxy_wallet_address: Option<String>,
    _signature_type: Option<u8>,
}

#[allow(dead_code)]
impl PolymarketApi {
    pub fn new(
        gamma_url: String,
        clob_url: String,
        api_key: Option<String>,
        api_secret: Option<String>,
        api_passphrase: Option<String>,
        private_key: Option<String>,
        proxy_wallet_address: Option<String>,
        signature_type: Option<u8>,
    ) -> Self {
        let client = Client::builder()
            .timeout(std::time::Duration::from_secs(10))
            .build()
            .expect("Failed to create HTTP client");
        
        Self {
            client,
            gamma_url,
            clob_url,
            api_key,
            api_secret,
            api_passphrase,
            private_key,
            proxy_wallet_address,
            _signature_type: signature_type,
        }
    }

    pub async fn authenticate(&self) -> Result<()> {
        let private_key = self.private_key.as_ref().ok_or_else(|| anyhow::anyhow!("Private key missing"))?;
        let signer = LocalSigner::from_str(private_key)?.with_chain_id(Some(POLYGON));
        
        let mut auth_builder = ClobClient::new(&self.clob_url, ClobConfig::default())?
            .authentication_builder(&signer);
        
        if let (Some(key), Some(secret), Some(pass)) = (&self.api_key, &self.api_secret, &self.api_passphrase) {
            auth_builder = auth_builder.credentials(polymarket_client_sdk::auth::Credentials::new(
                Uuid::from_str(key)?,
                secret.clone(),
                pass.clone(),
            ));
        }

        if let Some(proxy_addr) = &self.proxy_wallet_address {
            auth_builder = auth_builder.funder(Address::from_str(proxy_addr)?);
            auth_builder = auth_builder.signature_type(SignatureType::Proxy);
        }

        let _ = auth_builder.authenticate().await?;
        
        eprintln!("✅ Authenticated with CLOB API");
        Ok(())
    }

    pub async fn get_price(&self, token_id: &str, side: &str) -> Result<rust_decimal::Decimal> {
        let url = format!("{}/price", self.clob_url);
        let params = [("side", side), ("token_id", token_id)];
        let response = self.client.get(&url).query(&params).send().await?;
        let json: Value = response.json().await?;
        let price_str = json.get("price").and_then(|p| p.as_str()).unwrap_or("0");
        Ok(rust_decimal::Decimal::from_str(price_str)?)
    }

    pub async fn get_market_by_slug(&self, slug: &str) -> Result<Market> {
        let url = format!("{}/events/slug/{}", self.gamma_url, slug);
        let response = self.client.get(&url).send().await?;
        let json: Value = response.json().await?;
        if let Some(markets) = json.get("markets").and_then(|m| m.as_array()) {
            if let Some(market_json) = markets.first() {
                return Ok(serde_json::from_value(market_json.clone())?);
            }
        }
        anyhow::bail!("Market not found")
    }

    pub async fn get_market(&self, condition_id: &str) -> Result<MarketDetails> {
        let url = format!("{}/markets/{}", self.clob_url, condition_id);
        let response = self.client.get(&url).send().await?;
        Ok(response.json().await?)
    }

    pub async fn place_market_order(&self, token_id: &str, amount: f64, side: &str, _order_type: Option<&str>) -> Result<OrderResponse> {
        let private_key = self.private_key.as_ref().ok_or_else(|| anyhow::anyhow!("Private key missing"))?;
        let signer = LocalSigner::from_str(private_key)?.with_chain_id(Some(POLYGON));
        
        let mut auth_builder = ClobClient::new(&self.clob_url, ClobConfig::default())?
            .authentication_builder(&signer);
        
        if let (Some(key), Some(secret), Some(pass)) = (&self.api_key, &self.api_secret, &self.api_passphrase) {
            auth_builder = auth_builder.credentials(polymarket_client_sdk::auth::Credentials::new(
                Uuid::from_str(key)?,
                secret.clone(),
                pass.clone(),
            ));
        }

        if let Some(proxy_addr) = &self.proxy_wallet_address {
            auth_builder = auth_builder.funder(Address::from_str(proxy_addr)?);
            auth_builder = auth_builder.signature_type(SignatureType::Proxy);
        }

        let client_sdk = auth_builder.authenticate().await?;
        
        let side_enum = if side == "BUY" { Side::Buy } else { Side::Sell };
        let price = self.get_price(token_id, side).await?;
        
        // Aggressive pricing logic
        let adjusted_price = if side == "BUY" {
            let mut p = (price * rust_decimal::Decimal::from_str("1.1").unwrap()).round_dp(2);
            if p <= price { p = price + rust_decimal::Decimal::from_str("0.01").unwrap(); }
            if p > rust_decimal::Decimal::from_str("0.99").unwrap() { p = rust_decimal::Decimal::from_str("0.99").unwrap(); }
            p
        } else {
            let mut p = (price * rust_decimal::Decimal::from_str("0.9").unwrap()).round_dp(2);
            if p >= price { p = price - rust_decimal::Decimal::from_str("0.01").unwrap(); }
            if p < rust_decimal::Decimal::from_str("0.01").unwrap() { p = rust_decimal::Decimal::from_str("0.01").unwrap(); }
            p
        };

        let size = rust_decimal::Decimal::from_f64_retain(amount).unwrap().round_dp(2);
        
        crate::log_println!("📤 Order: {} {} {} @ ${:.4}", side, size, token_id, adjusted_price);

        let token_id_u256 = U256::from_str_radix(token_id, 10)?;

        let order = client_sdk.limit_order()
            .token_id(token_id_u256)
            .size(size)
            .price(adjusted_price)
            .side(side_enum);

        let signed = client_sdk.sign(&signer, order.build().await?).await?;
        let resp = client_sdk.post_order(signed).await?;
        
        if resp.success {
            crate::log_println!("✅ Order success: {}", resp.order_id);
        } else {
            crate::log_error!("Order failed: {:?}", resp.error_msg);
        }

        Ok(OrderResponse {
            order_id: Some(resp.order_id),
            status: resp.status.to_string(),
            message: resp.error_msg,
        })
    }

    pub async fn get_all_active_markets(&self, limit: u32) -> Result<Vec<Market>> {
        let url = format!("{}/events", self.gamma_url);
        let params = [("active", "true"), ("closed", "false"), ("limit", &limit.to_string())];
        let response = self.client.get(&url).query(&params).send().await?;
        let json: Value = response.json().await?;
        let mut all = Vec::new();
        if let Some(events) = json.as_array() {
            for e in events {
                if let Some(markets) = e.get("markets").and_then(|m| m.as_array()) {
                    for m in markets {
                        if let Ok(market) = serde_json::from_value(m.clone()) {
                            all.push(market);
                        }
                    }
                }
            }
        }
        Ok(all)
    }

    pub async fn get_balance(&self, address: &str) -> Result<BalanceResponse> {
        let url = format!("{}/balance/{}", self.clob_url, address);
        Ok(self.client.get(&url).send().await?.json().await?)
    }
    
    pub async fn redeem_tokens(&self, _condition_id: &str, _token_id: &str, _outcome: &str) -> Result<RedeemResponse> {
        Ok(RedeemResponse {
            success: true,
            message: Some("Redemption simulated".to_string()),
            transaction_hash: None,
            amount_redeemed: None,
        })
    }
}
