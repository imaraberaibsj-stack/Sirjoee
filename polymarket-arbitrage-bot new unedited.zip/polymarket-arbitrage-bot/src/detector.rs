use crate::monitor::MarketSnapshot;
use crate::models::MarketData;
use rust_decimal::Decimal;
use std::sync::Arc;
use tokio::sync::Mutex;
use std::collections::HashMap;

/// Detector for $0.99 trigger strategy (using ASK price)
pub struct PriceDetector {
    trigger_prices: Vec<f64>, // e.g. [0.99, 0.98, 0.97]
    min_time_remaining_seconds: u64, // 90 seconds
    current_period_bought_levels: Arc<Mutex<HashMap<u64, Vec<f64>>>>, // Track which period AND level we bought in
}

#[derive(Debug, Clone)]
pub struct BuyOpportunity {
    pub condition_id: String,
    pub market_name: String,
    pub token_to_buy_id: String,
    pub token_to_buy_name: String,
    pub _token_to_buy_price: f64,
    pub difference_d: f64,
    pub trigger_level: f64,
    pub period_timestamp: u64,
    pub _time_remaining_seconds: u64,
}

impl PriceDetector {
    pub fn new(trigger_prices: Vec<f64>, min_time_remaining_seconds: u64) -> Self {
        Self {
            trigger_prices,
            min_time_remaining_seconds,
            current_period_bought_levels: Arc::new(Mutex::new(HashMap::new())),
        }
    }

    pub async fn detect_opportunity(&self, snapshot: &MarketSnapshot) -> Vec<BuyOpportunity> {
        let mut opportunities = Vec::new();
        
        if snapshot.time_remaining_seconds == 0 {
            return opportunities;
        }

        // Check both ETH and BTC
        if let Some(opp) = self.check_market(&snapshot.eth_market, &snapshot.btc_market, snapshot.period_timestamp, snapshot.time_remaining_seconds).await {
            opportunities.push(opp);
        }
        
        if let Some(opp) = self.check_market(&snapshot.btc_market, &snapshot.eth_market, snapshot.period_timestamp, snapshot.time_remaining_seconds).await {
            opportunities.push(opp);
        }

        opportunities
    }

    async fn check_market(
        &self, 
        primary: &MarketData, 
        secondary: &MarketData, 
        period: u64,
        time_left: u64
    ) -> Option<BuyOpportunity> {
        let up = primary.up_token.as_ref()?;
        let down = primary.down_token.as_ref()?;
        
        let up_price = decimal_to_f64(up.ask.unwrap_or(rust_decimal::Decimal::ZERO));
        let down_price = decimal_to_f64(down.ask.unwrap_or(rust_decimal::Decimal::ZERO));

        let (higher_price, higher_is_up) = if up_price > down_price {
            (up_price, true)
        } else {
            (down_price, false)
        };

        // Find the highest trigger level that hasn't been bought yet
        let mut trigger_level = 0.0;
        for &level in &self.trigger_prices {
            if higher_price >= level {
                let bought_levels = self.current_period_bought_levels.lock().await;
                let already_bought = bought_levels.get(&period)
                    .map(|levels| levels.contains(&level))
                    .unwrap_or(false);
                
                if !already_bought {
                    trigger_level = level;
                    break;
                }
            }
        }

        if trigger_level == 0.0 {
            return None;
        }

        // BTC prices for D
        let sec_up = secondary.up_token.as_ref()?;
        let sec_down = secondary.down_token.as_ref()?;
        let sec_up_price = decimal_to_f64(sec_up.ask.unwrap_or(rust_decimal::Decimal::ZERO));
        let sec_down_price = decimal_to_f64(sec_down.ask.unwrap_or(rust_decimal::Decimal::ZERO));

        let difference_d = if higher_is_up {
            higher_price - sec_up_price
        } else {
            higher_price - sec_down_price
        };

        if difference_d < 0.01 {
            return None;
        }

        if difference_d < 0.06 && time_left <= self.min_time_remaining_seconds {
            return None;
        }

        let (token_to_buy_id, token_to_buy_name, token_to_buy_price) = if higher_is_up {
            (down.token_id.clone(), format!("{} Down", primary.market_name), decimal_to_f64(down.ask.unwrap_or(rust_decimal::Decimal::ZERO)))
        } else {
            (up.token_id.clone(), format!("{} Up", primary.market_name), decimal_to_f64(up.ask.unwrap_or(rust_decimal::Decimal::ZERO)))
        };

        // Ensure token we're buying has a valid price
        if token_to_buy_price <= 0.0 {
            return None;
        }

        Some(BuyOpportunity {
            condition_id: primary.condition_id.clone(),
            market_name: primary.market_name.clone(),
            token_to_buy_id,
            token_to_buy_name,
            _token_to_buy_price: token_to_buy_price,
            difference_d,
            trigger_level,
            period_timestamp: period,
            _time_remaining_seconds: time_left,
        })
    }

    pub async fn mark_level_bought(&self, period: u64, level: f64) {
        let mut bought_levels = self.current_period_bought_levels.lock().await;
        bought_levels.entry(period).or_insert_with(Vec::new).push(level);
    }

    pub async fn reset_period(&self) {
        let mut bought_levels = self.current_period_bought_levels.lock().await;
        bought_levels.clear();
    }
}

// Helper function for Decimal to f64 conversion
fn decimal_to_f64(d: Decimal) -> f64 {
    d.to_string().parse().unwrap_or(0.0)
}
