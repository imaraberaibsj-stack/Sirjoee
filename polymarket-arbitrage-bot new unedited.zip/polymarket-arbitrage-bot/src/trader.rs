use crate::api::PolymarketApi;
use crate::models::*;
use crate::detector::BuyOpportunity;
use crate::config::TradingConfig;
use anyhow::Result;
use log::debug;
use std::sync::Arc;
use tokio::sync::Mutex;
use std::collections::HashMap;

/// Calculate sell strategy based on D value
/// Returns (sell_points, sell_percentages)
fn calculate_sell_strategy(d: f64) -> (Vec<f64>, Vec<f64>) {
    if d >= 0.01 && d < 0.06 {
        // Sell all at $0.03
        (vec![0.03], vec![1.0])
    } else if d >= 0.06 && d < 0.1 {
        // Sell half at $0.03, rest at $0.05
        (vec![0.03, 0.05], vec![0.5, 1.0])
    } else if d >= 0.1 && d < 0.2 {
        // Sell half at $0.03, half of rest at $0.05, all rest at $0.07
        (vec![0.03, 0.05, 0.07], vec![0.5, 0.5, 1.0])
    } else if d >= 0.2 && d < 0.35 {
        // Sell half at $0.03, half of rest at $0.05, half of rest at $0.07, all rest at $0.10
        (vec![0.03, 0.05, 0.07, 0.10], vec![0.5, 0.5, 0.5, 1.0])
    } else if d >= 0.35 && d < 0.7 {
        // Sell half at $0.03, half of rest at $0.05, half of rest at $0.07, half of rest at $0.10, all rest at $0.15
        (vec![0.03, 0.05, 0.07, 0.10, 0.15], vec![0.5, 0.5, 0.5, 0.5, 1.0])
    } else if d >= 0.7 && d < 0.8 {
        // Sell half at $0.03, half of rest at $0.05, all rest at $0.07
        (vec![0.03, 0.05, 0.07], vec![0.5, 0.5, 1.0])
    } else if d >= 0.8 && d < 0.85 {
        // Sell half at $0.03, all rest at $0.05
        (vec![0.03, 0.05], vec![0.5, 1.0])
    } else {
        // d >= 0.85: Sell all at $0.03
        (vec![0.03], vec![1.0])
    }
}

pub struct Trader {
    api: Arc<PolymarketApi>,
    config: TradingConfig,
    simulation_mode: bool,
    total_profit: Arc<Mutex<f64>>,
    trades_executed: Arc<Mutex<u64>>,
    pending_trades: Arc<Mutex<HashMap<String, PendingTrade>>>, // Key: period_timestamp
}

impl Trader {
    pub fn new(api: Arc<PolymarketApi>, config: TradingConfig, simulation_mode: bool) -> Self {
        Self {
            api,
            config,
            simulation_mode,
            total_profit: Arc::new(Mutex::new(0.0)),
            trades_executed: Arc::new(Mutex::new(0)),
            pending_trades: Arc::new(Mutex::new(HashMap::new())),
        }
    }

    /// Execute buy when opportunity is detected
    pub async fn execute_buy(&self, opportunity: &BuyOpportunity) -> Result<()> {
        let fixed_amount = self.config.fixed_trade_amount;
        
        // Get current BID price for the token we're buying (what we pay to buy)
        // get_price(token_id, "BUY") returns BID price (what we pay, higher)
        let price_result = self.api.get_price(&opportunity.token_to_buy_id, "BUY").await;
        let price = match price_result {
            Ok(p) => p,
            Err(e) => {
                crate::log_warn!("Could not fetch BID price for token: {}", e);
                return Err(e);
            }
        };
        
        let price_f64 = f64::try_from(price).unwrap_or(0.0);
        
        // Safety check: reject if price is 0 or too low (market likely expired)
        if price_f64 <= 0.0 || price_f64 < 0.001 {
            crate::log_warn!("Invalid price for token: ${:.4} (market may be expired)", price_f64);
            return Err(anyhow::anyhow!("Invalid price: ${:.4}", price_f64));
        }
        
        let units = fixed_amount / price_f64;
        
        // Calculate sell strategy based on D
        let (sell_points, sell_percentages) = calculate_sell_strategy(opportunity.difference_d);
        
        crate::log_println!("❎ Buying {} (D={:.4})", opportunity.token_to_buy_name, opportunity.difference_d);
        
        if self.simulation_mode {
            crate::log_println!("✅ SIMULATION: Bought {:.2} units at ${:.4}", units, price_f64);
        } else {
            // Place real market order
            let units_rounded = (units * 10000.0).round() / 10000.0;
            
            match self.api.place_market_order(
                &opportunity.token_to_buy_id,
                units_rounded,
                "BUY",
                Some("FOK"),
            ).await {
                Ok(response) => {
                    crate::log_println!("   ✅ Order placed: {:?}", response);
                }
                Err(e) => {
                    crate::log_error!("Failed to place order: {}", e);
                    return Err(e);
                }
            }
        }
        
        // Track the trade
        let token_id = opportunity.token_to_buy_id.clone();
        crate::log_println!("   📝 Storing trade: Token ID: {}", &token_id[..16]);
        
        let trade = PendingTrade {
            token_id: token_id.clone(),
            condition_id: opportunity.condition_id.clone(),
            _investment_amount: fixed_amount,
            total_units: units,
            remaining_units: units,
            purchase_price: price_f64,
            _difference_d: opportunity.difference_d,
            _timestamp: std::time::Instant::now(),
            market_timestamp: opportunity.period_timestamp,
            sell_points,
            sell_percentages,
            next_sell_index: 0,
        };
        
        let trade_key = format!("{}_{}_{}", opportunity.period_timestamp, opportunity.market_name, opportunity.trigger_level);
        let mut pending = self.pending_trades.lock().await;
        pending.insert(trade_key, trade);
        drop(pending);
        
        crate::log_println!("   ✅ Trade stored successfully. Will monitor token price for sell points.");
        
        let mut trades = self.trades_executed.lock().await;
        *trades += 1;
        drop(trades);
        
        Ok(())
    }

    /// Check pending trades and sell at appropriate price points
    pub async fn check_pending_trades(&self) -> Result<()> {
        let pending_trades: Vec<(String, PendingTrade)> = {
            let pending = self.pending_trades.lock().await;
            pending.iter()
                .map(|(key, trade)| (key.clone(), trade.clone()))
                .collect()
        };
        
        for (key, mut trade) in pending_trades {
            // Skip if all units are sold
            if trade.remaining_units <= 0.0 || trade.next_sell_index >= trade.sell_points.len() {
                continue;
            }
            
            // Get current ASK price (what we receive when selling - SELL side)
            // get_price(token_id, "SELL") returns ASK price (what we get when selling, lower)
            let price_result = self.api.get_price(&trade.token_id, "SELL").await;
            let current_ask_price = match price_result {
                Ok(p) => {
                    let price_f64 = f64::try_from(p).unwrap_or(0.0);
                    debug!("Checking token {} ASK price: ${:.4} (purchased at BID ${:.4})", 
                           &trade.token_id[..16], price_f64, trade.purchase_price);
                    price_f64
                },
                Err(e) => {
                    debug!("Failed to get ASK price for token {}: {}", &trade.token_id[..16], e);
                    continue; // Skip if can't get price
                }
            };
            
            // Check if we've reached the next sell point (using ASK price - what we'll receive)
            let next_sell_point = trade.sell_points[trade.next_sell_index];
            
            debug!("Token ASK price: ${:.4}, next sell point: ${:.4}, remaining units: {:.2}", 
                   current_ask_price, next_sell_point, trade.remaining_units);
            
            if current_ask_price >= next_sell_point {
                // Calculate how much to sell
                let sell_percentage = trade.sell_percentages[trade.next_sell_index];
                let units_to_sell = if trade.next_sell_index == 0 {
                    // First sell: sell percentage of total
                    trade.total_units * sell_percentage
                } else {
                    // Subsequent sells: sell percentage of remaining
                    trade.remaining_units * sell_percentage
                };
                
                crate::log_println!("📈 Selling {} (at ${:.4})", trade.token_id, current_ask_price);
                
                // Execute sell using ASK price (what we'll receive)
                if let Err(e) = self.execute_sell(&key, &mut trade, units_to_sell, current_ask_price).await {
                    crate::log_error!("Error executing sell: {}", e);
                    continue;
                }
                
                // Update trade state
                trade.remaining_units -= units_to_sell;
                trade.next_sell_index += 1;
                
                // Update in HashMap
                let mut pending = self.pending_trades.lock().await;
                if let Some(t) = pending.get_mut(&key) {
                    *t = trade;
                }
                drop(pending);
            }
        }
        
        Ok(())
    }

    /// Execute sell order
    async fn execute_sell(
        &self,
        _trade_key: &str,
        trade: &PendingTrade,
        units_to_sell: f64,
        current_price: f64,
    ) -> Result<()> {
        if self.simulation_mode {
            let sell_value = current_price * units_to_sell;
            let profit = sell_value - (trade.purchase_price * units_to_sell);
            
            let mut total = self.total_profit.lock().await;
            *total += profit;
            let total_profit = *total;
            drop(total);
            
            crate::log_println!("✅ SIMULATION: Sold {:.2} units at ${:.4} | Profit: ${:.4} | Total: ${:.2}", units_to_sell, current_price, profit, total_profit);
        } else {
            // Place real market sell order
            match self.api.place_market_order(
                &trade.token_id,
                units_to_sell,
                "SELL",
                Some("FOK"),
            ).await {
                Ok(response) => {
                    crate::log_println!("   ✅ Sell order placed: {:?}", response);
                }
                Err(e) => {
                    crate::log_error!("Failed to place sell order: {}", e);
                    return Err(e);
                }
            }
        }
        
        Ok(())
    }

    /// Check and settle trades when markets close
    pub async fn check_market_closure(&self) -> Result<()> {
        let pending_trades: Vec<(String, PendingTrade)> = {
            let pending = self.pending_trades.lock().await;
            pending.iter()
                .map(|(key, trade)| (key.clone(), trade.clone()))
                .collect()
        };
        
        let current_timestamp = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_secs();
        
        for (key, trade) in pending_trades {
            // Market closes at market_timestamp + 900 seconds
            let market_end_timestamp = trade.market_timestamp + 900;
            
            if current_timestamp < market_end_timestamp - 30 {
                continue; // Market hasn't closed yet
            }
            
            // Check if market is closed and redeem if winner
            let (market_closed, is_winner) = self.check_market_result(&trade.condition_id, &trade.token_id).await?;
            
            if market_closed && is_winner && trade.remaining_units > 0.0 {
                // Redeem winning tokens
                if !self.simulation_mode {
                    let _ = self.redeem_token(&trade).await;
                }
                
                // Calculate profit from remaining units (worth $1.00 each if winner)
                let remaining_value = trade.remaining_units * 1.0;
                let remaining_cost = trade.purchase_price * trade.remaining_units;
                let profit = remaining_value - remaining_cost;
                
                let mut total = self.total_profit.lock().await;
                *total += profit;
                drop(total);
                
                crate::log_println!("✅ WON: {} (Period {}) | Profit: ${:.4}", trade.token_id, trade.market_timestamp, profit);
                
                // Remove trade
                let mut pending = self.pending_trades.lock().await;
                pending.remove(&key);
            } else if market_closed && !is_winner && trade.remaining_units > 0.0 {
                crate::log_println!("❌ LOST: {} (Period {})", trade.token_id, trade.market_timestamp);
                // Remove trade
                let mut pending = self.pending_trades.lock().await;
                pending.remove(&key);
            }
        }
        
        Ok(())
    }

    async fn check_market_result(&self, condition_id: &str, token_id: &str) -> Result<(bool, bool)> {
        let market = self.api.get_market(condition_id).await?;
        
        let is_closed = market.closed;
        let is_winner = market.tokens.iter()
            .any(|t| t.token_id == token_id && t.winner);
        
        Ok((is_closed, is_winner))
    }

    async fn redeem_token(&self, trade: &PendingTrade) -> Result<()> {
        // Implementation for token redemption
        // This would call the API to redeem winning tokens
        crate::log_println!("🔄 Redeeming {} units of token {}", trade.remaining_units, &trade.token_id[..16]);
        Ok(())
    }

    /// Reset for new period
    pub async fn reset_period(&self, old_period: u64) {
        let mut pending = self.pending_trades.lock().await;
        // Remove trades from old period
        pending.retain(|_, trade| trade.market_timestamp != old_period);
        drop(pending);
    }
}



